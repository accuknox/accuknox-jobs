{{/*
Expand the name of the chart.
*/}}
{{- define "cis-k8s-job.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "cis-k8s-job.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cis-k8s-job.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cis-k8s-job.labels" -}}
helm.sh/chart: {{ include "cis-k8s-job.chart" . }}
{{ include "cis-k8s-job.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cis-k8s-job.selectorLabels" -}}
app.kubernetes.io/name: {{ include "cis-k8s-job.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "cis-k8s-job.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "cis-k8s-job.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "volumes" }}
- name: datapath
  emptyDir: {}
- name: var-lib-kubelet
  hostPath:
    path: "/var/lib/kubelet"
- name: etc-systemd
  hostPath:
    path: "/etc/systemd"
- name: etc-kubernetes
  hostPath:
    path: "/etc/kubernetes"
{{- if eq .platform "GKE" }}
# Use emptyDir for paths that are read-only on GKE
- name: home-kubernetes
  emptyDir: {}
- name: srv-kubernetes
  emptyDir: {}
- name: opt-cni-bin
  emptyDir: {}
- name: etc-cni-netd
  emptyDir: {}
- name: usr-bin
  emptyDir: {}
{{- else if .platform | empty }}
- name: var-lib-cni
  hostPath:
    path: /var/lib/cni
- hostPath:
    path: /var/lib/etcd
  name: var-lib-etcd
- hostPath:
    path: /var/lib/kube-scheduler
  name: var-lib-kube-scheduler
- hostPath:
    path: /var/lib/kube-controller-manager
  name: var-lib-kube-controller-manager
- hostPath:
    path: /lib/systemd
  name: lib-systemd
- hostPath:
    path: /srv/kubernetes
  name: srv-kubernetes
- hostPath:
    path: /usr/bin
  name: usr-bin
- hostPath:
    path: /etc/cni/net.d/
  name: etc-cni-netd
- hostPath:
    path: /opt/cni/bin/
  name: opt-cni-bin
{{- else if eq .platform "AKS" }}
- name: etc-default
  hostPath:
    path: "/etc/default"
{{- end }}
{{- end }}

{{- define "volumeMounts" }}
- mountPath: /data
  name: datapath
- name: var-lib-kubelet
  mountPath: /var/lib/kubelet
  readOnly: true
- name: etc-systemd
  mountPath: /etc/systemd
  readOnly: true
- name: etc-kubernetes
  mountPath: /etc/kubernetes
  readOnly: true
{{- if eq .platform "GKE" }}
- name: home-kubernetes
  mountPath: /home/kubernetes
  readOnly: true
- name: srv-kubernetes
  mountPath: /srv/kubernetes
  readOnly: false
- name: opt-cni-bin
  mountPath: /opt/cni/bin
  readOnly: false
- name: etc-cni-netd
  mountPath: /etc/cni/net.d
  readOnly: false
- name: usr-bin
  mountPath: /usr/local/mount-from-host/bin
  readOnly: false
{{- else if .platform | empty }}
- name: var-lib-cni
  mountPath: /var/lib/cni
  readOnly: true
- mountPath: /var/lib/etcd
  name: var-lib-etcd
  readOnly: true
- mountPath: /var/lib/kube-scheduler
  name: var-lib-kube-scheduler
  readOnly: true
- mountPath: /var/lib/kube-controller-manager
  name: var-lib-kube-controller-manager
  readOnly: true
- mountPath: /lib/systemd/
  name: lib-systemd
  readOnly: true
{{- else if eq .platform "AKS" }}
- name: etc-default
  mountPath: /etc/default
  readOnly: true
{{- end }}
{{- end }}

{{- define "cmd" }}
- kube-bench
- run
- --json
- --outputfile=/data/report.json
{{- if not (.targets | empty) }}
- --targets="{{ .targets }}"
{{- end }}
{{- if not (.benchmark | empty) }}
- --benchmark="{{ .benchmark }}"
{{- end }}
{{- if not (.check | empty) }}
- --check="{{ .check }}"
{{- end }}
{{- if not (.skip | empty) }}
- --skip="{{ .skip }}"
{{- end }}
{{- end }}

{{- define "masterConfig" }}
affinity:
  nodeAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      nodeSelectorTerms:
        - matchExpressions:
            - key: node-role.kubernetes.io/control-plane
              operator: Exists
        - matchExpressions:
            - key: node-role.kubernetes.io/master
              operator: Exists
tolerations:
  - key: node-role.kubernetes.io/master
    operator: Exists
    effect: NoSchedule
  - key: node-role.kubernetes.io/control-plane
    operator: Exists
    effect: NoSchedule
{{- end }}


{{- define "image-name" -}}

  {{- $image := .image -}}
  {{- $url := .url -}}
  {{- $owner := .owner -}}
  {{- $repoName := .repoName -}}
  {{- $tag := .tag -}}
  {{- $preserve := .preserve -}}
  {{- $suffix := .suffix -}}

  {{- if $image -}}
    {{- $image -}}
  {{- else -}}

    {{- $parts := list -}}

    {{- if $url -}}
      {{- $parts = append $parts $url -}}
    {{- end -}}

    {{- if $preserve -}}
	    {{- if $owner -}}
	      {{- $parts = append $parts $owner -}}
	    {{- end -}}
	  {{- end -}}

    {{- if $repoName -}}
      {{- if $suffix -}}
        {{- $repoName = printf "%s-%s" $repoName $suffix -}}
      {{- end -}}
      {{- $parts = append $parts $repoName -}}
    {{- end -}}

    {{- $imageName := join "/" $parts -}}

    {{- if $tag -}}
      {{- printf "%s:%s" $imageName $tag -}}
    {{- else -}}
      {{- $imageName -}}
    {{- end -}}

  {{- end -}}

{{- end -}}


{{- define "cluster_job.image" -}}
  {{ include "image-name" (dict "url" .Values.registry.url "owner" .Values.cluster_job.owner "repoName" .Values.cluster_job.repository "tag" .Values.cluster_job.tag "preserve" .Values.registry.preserveUpstream "image" .Values.cluster_job.image ) }}
{{- end -}}

{{- define "kubeBench.image" -}}
  {{ include "image-name" (dict "url" .Values.registry.url "owner" .Values.kubeBench.owner "repoName" .Values.kubeBench.repository "tag" .Values.kubeBench.tag "preserve" .Values.registry.preserveUpstream "image" .Values.kubeBench.image ) }}
{{- end -}}

{{/* Construct the URL for jobs */}}
{{- define "global.jobURL" -}}
{{- if and .Values.global.enableJobsUrl .Values.global.agents.url -}}
cspm.{{ .Values.global.agents.url -}}
{{- else -}}
{{- default "" .Values.global.enableJobsUrl -}}
{{- end -}}
{{- end -}}


{{- define "spire.enabled" -}}
  {{- if and (or (ne .Values.global.agents.joinToken "") (ne .Values.global.agents.accessKey "")) (eq .Values.global.authToken "") -}}
    true
  {{- else -}}
    false
  {{- end -}}
{{- end -}}


{{/*
Return full spire host like spire.dev.accuknox.com or localhost
*/}}
{{- define "jobs.spireHost" -}}
{{- if eq (include "spire.enabled" . ) "true" }}spire.{{ .Values.global.agents.url }}{{- else -}}localhost{{- end -}}
{{- end }}



{{/*
Return KnoxGateway URL with port, like knox-gw.dev.accuknox.com:3000 or empty
*/}}
{{- define "jobs.knoxGatewayHost" -}}
{{- if eq (include "spire.enabled" . ) "true" }}knox-gw.{{ .Values.global.agents.url }}:3000{{- else -}}{{""}}{{- end -}}
{{- end }}


{{/*
Return access key URL, like cwpp.dev.accuknox.com/access-token/api/v1/process or empty
*/}}
{{- define "jobs.accessKeyUrl" -}}
{{- if .Values.global.agents.accessKey -}}https://cwpp.{{ .Values.global.agents.url }}/access-token/api/v1/process{{- else -}}{{""}}{{- end -}}
{{- end }}


{{/*
Return cluster name for spire access keys
*/}}
{{- define "jobs.clusterName" -}}
{{- if  ne .Values.global.clusterName "" -}}
    {{- .Values.global.clusterName -}}
{{- else if ne .Values.global.agents.clusterName "" -}}
    {{- .Values.global.agents.clusterName -}}
{{- else -}}
    ""
{{- end -}}
{{- end -}}