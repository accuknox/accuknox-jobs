{{/*
Expand the name of the chart.
*/}}
{{- define "kubeshield-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "kubeshield-chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubeshield-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kubeshield-chart.labels" -}}
app: local-registry-agent
helm.sh/chart: {{ include "kubeshield-chart.chart" . }}
{{ include "kubeshield-chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubeshield-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubeshield-chart.name" . }}
control-plane: controller-manager
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kubeshield-chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kubeshield-chart.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{/*
Spire agent tpl
*/}}

{{- define "spire.namespace"  }}
{{- .Values.namespace | default .Release.Namespace }}
{{- end }}

{{- define "spire.healthCheck.port" }}
{{- .Values.healthCheck.port | default 9090 }}
{{- end }}

{{- define "spire.agent.default.labels" -}}
component: spire
app: spire-agent
{{- end }}

{{- define "spire.agent.secret.name" -}}
{{ include "spire.agent.name" . }}-secret
{{- end }}

{{- define "spire.agent.name" }}
{{- if .Values.global.agents.enabled -}}
agents-operator
{{- else }}
{{- .Values.agent.name | default "spire-agent" }}
{{- end }}
{{- end }}

{{- define "spire.server.port" }}
{{- .Values.server.config.port | default 8081 }}
{{- end }}

{{- define "spire.agent.port" }}
{{- .Values.agent.config.port | default 9091 }}
{{- end }}

{{- define "spire.agent.dataDir" }}
{{- .Values.agent.config.dataDir | default "/run/spire/data" }}
{{- end }}

{{/* Construct the URL for Scan */}}
{{- define "global.ScanURL" -}}
{{- if and .Values.global.inClusterScan .Values.global.agents.url -}}
cspm.{{ .Values.global.agents.url -}}
{{- else -}}
{{- default "" .Values.global.inClusterScan -}}
{{- end -}}
{{- end -}}


{{/* SPiRE is enabled if joinToken, accessKey, or authToken is provided */}}
{{- define "spire.enabled" -}}
  {{- if or (ne .Values.global.agents.joinToken "") (ne .Values.global.agents.accessKey "") (ne .Values.global.authToken "") -}}
    true
  {{- else -}}
    false
  {{- end -}}
{{- end -}}


{{/*
Return full spire host like spire.dev.accuknox.com or localhost
*/}}
{{- define "scans.spireHost" -}}
{{- if include "spire.enabled" . }}spire.{{ .Values.global.agents.url }}{{- else -}}localhost{{- end -}}
{{- end }}


{{/*
Return KnoxGateway URL with port, like knox-gw.dev.accuknox.com:3000 or empty
*/}}
{{- define "scans.knoxGatewayHost" -}}
{{- if include "spire.enabled" . }}knox-gw.{{ .Values.global.agents.url }}:3000{{- else -}}{{""}}{{- end -}}
{{- end }}

{{/*
Return KnoxGateway URL with port, like knox-gw.dev.accuknox.com:3000 or empty
*/}}
{{- define "scans.ppsHost" -}}
{{- if include "spire.enabled" . }}pps.{{ .Values.global.agents.url }}{{- else -}}{{""}}{{- end -}}
{{- end }}

{{/*
Return access key URL, like cwpp.dev.accuknox.com/access-token/api/v1/process or empty
*/}}
{{- define "scans.accessKeyUrl" -}}
{{- if .Values.global.agents.accessKey -}}https://cwpp.{{ .Values.global.agents.url }}/access-token/api/v1/process{{- else -}}{{""}}{{- end -}}
{{- end }}


{{- define "image-name" -}}
  {{- $url := .url | default "" -}}
  {{- $repo := .repoName | default "" -}}
  {{- $tag := .tag | default "" -}}
  {{- $preserve := .preserve | default false -}}

  {{- $parts := list -}}

  {{- if $url }}
    {{- $parts = append $parts $url }}
  {{- end }}

  {{- $parts = append $parts $repo }}

  {{- $imageName := join "/" $parts }}

  {{- if $tag }}
    {{- printf "%s:%s" $imageName $tag }}
  {{- else }}
    {{- $imageName }}
  {{- end }}
{{- end }}


{{- define "kubeshield.image" -}}
  {{ include "image-name" (dict "url" .Values.global.registry.url "repoName" .Values.image.repository "tag" .Values.image.tag "preserve" .Values.global.registry.preserveUpstream )}}
{{- end -}}

{{- define "trivyDB.image" -}}
  {{ include "image-name" (dict "url" .Values.global.registry.url "repoName" .Values.scan.trivyConfig.dbRepositories "preserve" .Values.global.registry.preserveUpstream )}}
{{- end -}}